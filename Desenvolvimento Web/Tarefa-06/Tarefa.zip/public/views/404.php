<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Not Found</title>
</head>
<body>
  <h1>404 - Página não encontrada</h1>
  <p>A página que você procura não existe.</p>
  <a href="/">Ir ao início</a></body>
</html>